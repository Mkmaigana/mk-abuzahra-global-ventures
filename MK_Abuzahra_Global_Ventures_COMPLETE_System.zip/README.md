# MK Abuzahra Global Ventures Ltd — Complete Sales & Commission System

This is the consolidated private company portal for advertiser registration, Super Admin approval, Sale Claims, one-time authenticators, verification/redemption, commissions, products, and system settings.

## 1. Supabase setup — one time
1. Open your Supabase project SQL Editor.
2. Open **FINAL_SYSTEM.sql** from this package and run the whole file once.
3. Do **NOT** run the old `migration_007_complete.sql` or the previous chapter patches.
4. Keep the existing Super Admin profile. The system expects the real `profiles.status` field.
5. Add your products from the Super Admin dashboard before advertisers create claims.

The browser uses only the Supabase project URL and publishable browser key. Never put a secret/service-role key in this website.

## 2. Authentication
Create/keep the Super Admin Auth user in Supabase Authentication → Users. Its profile must have role `super_admin` and status `active`.

Advertisers can register from the login page. If email confirmation is enabled, they confirm their email and then sign in. The system completes their advertiser profile automatically and leaves it **PENDING** until Super Admin approval.

## 3. End-to-end workflow
Advertiser registers → Super Admin approves → advertiser creates Sale Claim → server generates a unique 6-digit one-time authenticator → customer presents code + phone → staff/admin verifies → payment is confirmed → sale is redeemed → authenticator is permanently used → commission remains PENDING until Super Admin marks it ELIGIBLE → Super Admin marks it PAID.

## 4. Anti-fraud
- Authenticator is generated server-side and stored as a SHA-256 hash.
- It is one-time and has an expiry.
- Customer phone is checked during verification.
- Advertiser cannot set their own code or mark a commission paid.
- Sensitive actions are protected by database functions and RLS.
- Audit records are written for major actions.

## 5. Super Admin settings
Super Admin can change company name, logo URL, commission percentage, claim validity, partial-payment redemption rule, announcement, and advertiser dashboard feature configuration fields without editing JavaScript.

## 6. Deployment
This is a static web application. Upload the folder to a static host such as Cloudflare Pages, Netlify, Vercel, or GitHub Pages. The deployment URL becomes the real login link.

## Important
This package is intentionally consolidated around the `mk_*` tables/functions so it does not depend on incompatible legacy sales/commission tables from earlier prototypes.
