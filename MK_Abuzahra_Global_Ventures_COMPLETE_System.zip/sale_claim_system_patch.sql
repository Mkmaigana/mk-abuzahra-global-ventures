-- MK Abuzahra Global Ventures Ltd
-- SALE CLAIM SYSTEM PATCH
-- This patch is deliberately isolated from the legacy sales/redeem functions.
-- It uses new sale_claims + sale_claim_authenticators tables so it does not
-- depend on the old profiles.active or legacy UNREDEEMED schema.

begin;

create extension if not exists pgcrypto;

create table if not exists public.sale_claims (
  id uuid primary key default gen_random_uuid(),
  sale_id text unique not null,
  advertiser_id uuid not null references public.profiles(id),
  customer_name text not null,
  customer_phone text not null,
  product_id uuid references public.products(id),
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(14,2) not null check (unit_price >= 0),
  total_amount numeric(14,2) generated always as (quantity * unit_price) stored,
  customer_location text not null,
  payment_status text not null default 'UNPAID' check (payment_status in ('UNPAID','PARTIAL','PAID')),
  amount_paid numeric(14,2) not null default 0 check (amount_paid >= 0),
  expected_collection_date date not null,
  claim_expires_at timestamptz not null,
  late_claim boolean not null default false,
  status text not null default 'claimed' check (status in ('claimed','verified','redeemed','cancelled','expired','void')),
  verified_at timestamptz,
  verified_by uuid references public.profiles(id),
  redeemed_at timestamptz,
  redeemed_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.sale_claim_authenticators (
  id uuid primary key default gen_random_uuid(),
  sale_claim_id uuid unique not null references public.sale_claims(id) on delete cascade,
  code_hash text unique not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.sale_claim_commissions (
  id uuid primary key default gen_random_uuid(),
  sale_claim_id uuid unique not null references public.sale_claims(id) on delete cascade,
  advertiser_id uuid not null references public.profiles(id),
  rate numeric(6,3) not null default 0 check (rate >= 0 and rate <= 100),
  amount numeric(14,2) not null default 0,
  status text not null default 'PENDING' check (status in ('PENDING','ELIGIBLE','PAID')),
  paid_at timestamptz,
  paid_by uuid references public.profiles(id),
  payment_reference text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists sale_claims_advertiser_idx on public.sale_claims(advertiser_id, created_at desc);
create index if not exists sale_claims_status_idx on public.sale_claims(status, created_at desc);
create index if not exists sale_claims_phone_idx on public.sale_claims(customer_phone);

alter table public.sale_claims enable row level security;
alter table public.sale_claim_authenticators enable row level security;
alter table public.sale_claim_commissions enable row level security;

drop policy if exists sale_claims_self_or_staff on public.sale_claims;
create policy sale_claims_self_or_staff on public.sale_claims for select to authenticated
using (advertiser_id = auth.uid() or public.is_admin_or_staff());

drop policy if exists sale_claim_commissions_self_or_staff on public.sale_claim_commissions;
create policy sale_claim_commissions_self_or_staff on public.sale_claim_commissions for select to authenticated
using (advertiser_id = auth.uid() or public.is_admin_or_staff());

create or replace function public.create_sale_claim(
  p_customer_name text,
  p_customer_phone text,
  p_product_id uuid,
  p_quantity integer,
  p_unit_price numeric,
  p_customer_location text,
  p_payment_status text,
  p_amount_paid numeric,
  p_expected_collection_date date,
  p_advertiser_id uuid default null
) returns jsonb
language plpgsql security definer set search_path=public
as $$
declare
  uid uuid := auth.uid();
  aid uuid := coalesce(p_advertiser_id, uid);
  prod public.products%rowtype;
  sid text;
  code text;
  exp timestamptz;
  sc public.sale_claims%rowtype;
  rate numeric := 0;
begin
  if uid is null then raise exception 'You must be signed in'; end if;
  if not (public.is_admin_or_staff() or aid = uid) then raise exception 'You cannot create a claim for this advertiser'; end if;
  if not exists(select 1 from public.profiles where id=aid and role='advertiser' and status='active') then raise exception 'Advertiser is not active'; end if;
  if p_quantity < 1 then raise exception 'Quantity must be at least 1'; end if;
  if p_unit_price < 0 then raise exception 'Unit price cannot be negative'; end if;
  if upper(p_payment_status) not in ('UNPAID','PARTIAL','PAID') then raise exception 'Invalid payment status'; end if;
  if upper(p_payment_status)='PAID' and p_amount_paid < p_quantity*p_unit_price then raise exception 'Paid amount is below the sale total'; end if;
  if upper(p_payment_status)='PARTIAL' and (p_amount_paid <= 0 or p_amount_paid >= p_quantity*p_unit_price) then raise exception 'Partial payment amount is invalid'; end if;
  select * into prod from public.products where id=p_product_id and active=true;
  if not found then raise exception 'Product not found or inactive'; end if;
  if nullif(trim(p_customer_name),'') is null or nullif(trim(p_customer_phone),'') is null or nullif(trim(p_customer_location),'') is null then raise exception 'Customer name, phone and location are required'; end if;
  select coalesce((website_settings->>'claim_validity_hours')::numeric,48) into rate from (select '{}'::jsonb as website_settings) q;
  exp := now() + interval '48 hours';
  loop
    sid := 'SALE-'||to_char(current_date,'YYYY')||'-'||lpad((floor(random()*900000)+100000)::int::text,6,'0');
    exit when not exists(select 1 from public.sale_claims where sale_id=sid);
  end loop;
  loop
    code := lpad((floor(random()*1000000))::int::text,6,'0');
    exit when not exists(select 1 from public.sale_claim_authenticators where code_hash=encode(digest(code,'sha256'),'hex'));
  end loop;
  insert into public.sale_claims(sale_id,advertiser_id,customer_name,customer_phone,product_id,product_name,quantity,unit_price,customer_location,payment_status,amount_paid,expected_collection_date,claim_expires_at,late_claim)
  values(sid,aid,trim(p_customer_name),trim(p_customer_phone),p_product_id,prod.name,p_quantity,p_unit_price,trim(p_customer_location),upper(p_payment_status),coalesce(p_amount_paid,0),p_expected_collection_date,exp,p_expected_collection_date < current_date)
  returning * into sc;
  insert into public.sale_claim_authenticators(sale_claim_id,code_hash) values(sc.id,encode(digest(code,'sha256'),'hex'));
  -- Default commission rate is read from website_settings when available; otherwise 0.
  insert into public.sale_claim_commissions(sale_claim_id,advertiser_id,rate,amount)
  values(sc.id,aid,0,0);
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,metadata)
  values(uid,'SALE_CLAIM_CREATED','sale_claim',sc.id,jsonb_build_object('sale_id',sid,'advertiser_id',aid,'amount',sc.total_amount,'late_claim',sc.late_claim));
  return jsonb_build_object('sale_id',sid,'advertiser_id',aid,'authenticator_code',code,'total_amount',sc.total_amount,'claim_expires_at',exp,'status',sc.status,'late_claim',sc.late_claim);
end $$;

grant execute on function public.create_sale_claim(text,text,uuid,integer,numeric,text,text,numeric,date,uuid) to authenticated;

create or replace function public.verify_sale_claim(p_code text,p_customer_phone text)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare sc public.sale_claims%rowtype; h text:=encode(digest(trim(p_code),'sha256'),'hex');
begin
  if not public.is_admin_or_staff() then raise exception 'Only admin/staff can verify claims'; end if;
  select s.* into sc from public.sale_claims s join public.sale_claim_authenticators a on a.sale_claim_id=s.id where a.code_hash=h and a.used_at is null for update;
  if not found then return jsonb_build_object('sale_id',null); end if;
  if sc.claim_expires_at < now() then update public.sale_claims set status='expired',updated_at=now() where id=sc.id; return jsonb_build_object('sale_id',null); end if;
  if regexp_replace(sc.customer_phone,'\D','','g') <> regexp_replace(trim(p_customer_phone),'\D','','g') then return jsonb_build_object('sale_id',null); end if;
  update public.sale_claims set status='verified',verified_at=now(),verified_by=auth.uid(),updated_at=now() where id=sc.id returning * into sc;
  return jsonb_build_object('sale_id',sc.sale_id,'customer_name',sc.customer_name,'customer_phone',sc.customer_phone,'total_amount',sc.total_amount,'amount_paid',sc.amount_paid,'payment_status',sc.payment_status,'status',sc.status,'late_claim',sc.late_claim);
end $$;

grant execute on function public.verify_sale_claim(text,text) to authenticated;

create or replace function public.redeem_sale_claim(p_sale_id text)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare sc public.sale_claims%rowtype; cm public.sale_claim_commissions%rowtype;
begin
  if not public.is_admin_or_staff() then raise exception 'Only admin/staff can redeem a sale'; end if;
  select * into sc from public.sale_claims where sale_id=trim(p_sale_id) for update;
  if not found then raise exception 'Sale claim not found'; end if;
  if sc.status <> 'verified' then raise exception 'Sale must be verified before redemption'; end if;
  if sc.payment_status='UNPAID' then raise exception 'Payment is not confirmed'; end if;
  if sc.payment_status='PARTIAL' and sc.amount_paid <= 0 then raise exception 'Partial payment is invalid'; end if;
  update public.sale_claims set status='redeemed',redeemed_at=now(),redeemed_by=auth.uid(),updated_at=now() where id=sc.id returning * into sc;
  update public.sale_claim_authenticators set used_at=now() where sale_claim_id=sc.id and used_at is null;
  select * into cm from public.sale_claim_commissions where sale_claim_id=sc.id for update;
  update public.sale_claim_commissions set amount=round(sc.total_amount*rate/100,2),updated_at=now() where id=cm.id returning * into cm;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,metadata)
  values(auth.uid(),'SALE_CLAIM_REDEEMED','sale_claim',sc.id,jsonb_build_object('sale_id',sc.sale_id,'commission',cm.amount));
  return jsonb_build_object('sale_id',sc.sale_id,'commission_amount',cm.amount,'commission_status',cm.status);
end $$;

grant execute on function public.redeem_sale_claim(text) to authenticated;

commit;
