-- MK Abuzahra Global Ventures
-- Advertiser Registration + Pending Approval patch
-- Run this ONCE in Supabase SQL Editor after the V7 FIXED patch.

begin;

create table if not exists public.advertiser_details (
  id uuid primary key references public.profiles(id) on delete cascade,
  phone text not null,
  address text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists advertiser_details_phone_idx on public.advertiser_details(phone);

alter table public.advertiser_details enable row level security;

drop policy if exists advertiser_details_self_or_admin on public.advertiser_details;
create policy advertiser_details_self_or_admin
on public.advertiser_details for select
to authenticated
using (id = auth.uid() or public.is_admin_or_staff());

create or replace function public.register_advertiser_profile(
  p_full_name text,
  p_phone text,
  p_address text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  r public.profiles%rowtype;
begin
  if uid is null then raise exception 'You must be signed in to complete registration'; end if;
  if nullif(trim(p_full_name),'') is null then raise exception 'Full name is required'; end if;
  if nullif(trim(p_phone),'') is null then raise exception 'Phone number is required'; end if;
  if nullif(trim(p_address),'') is null then raise exception 'Address is required'; end if;

  insert into public.profiles(id, full_name, role, status)
  values(uid, trim(p_full_name), 'advertiser', 'pending')
  on conflict (id) do update set
    full_name = excluded.full_name,
    role = 'advertiser',
    status = case when public.profiles.status='active' then 'active' else 'pending' end,
    updated_at = now()
  returning * into r;

  insert into public.advertiser_details(id, phone, address)
  values(uid, trim(p_phone), trim(p_address))
  on conflict (id) do update set phone=excluded.phone,address=excluded.address,updated_at=now();

  return jsonb_build_object('id',r.id,'status',r.status);
end;
$$;

grant execute on function public.register_advertiser_profile(text,text,text) to authenticated;

create or replace function public.set_advertiser_status(
  p_advertiser_id uuid,
  p_status text,
  p_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare r public.profiles%rowtype; s text:=lower(trim(p_status));
begin
  if not public.is_super_admin() then raise exception 'Only Super Admin can manage advertiser approval'; end if;
  if s not in ('pending','approved','rejected','suspended','active') then raise exception 'Invalid advertiser status'; end if;
  select * into r from public.profiles where id=p_advertiser_id and role='advertiser' for update;
  if not found then raise exception 'Advertiser not found'; end if;
  update public.profiles set status=case when s in ('approved','active') then 'active' else s end,
    approval_note=case when nullif(trim(p_note),'') is not null then trim(p_note) else approval_note end,
    approved_at=case when s in ('approved','active') then now() else approved_at end,
    approved_by=case when s in ('approved','active') then auth.uid() else approved_by end,
    updated_at=now() where id=r.id returning * into r;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,metadata)
  values(auth.uid(),'ADVERTISER_STATUS_CHANGED','profile',r.id,jsonb_build_object('status',r.status,'note',p_note));
  return jsonb_build_object('id',r.id,'status',r.status,'approval_note',r.approval_note,'approved_at',r.approved_at);
end;
$$;

grant execute on function public.set_advertiser_status(uuid,text,text) to authenticated;

commit;
